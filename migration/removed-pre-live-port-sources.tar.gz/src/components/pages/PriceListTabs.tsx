"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { getPackageGroup } from "@/data/packages";
import { getPriceItem } from "@/data/pricelist";
import { formatPrice } from "@/lib/format";
import { whatsappLink } from "@/lib/whatsapp";

/**
 * The price list with its category tabs, as on /seminyak/.
 *
 * Tab buttons are measured from the live site: fully rounded, 17px / 600,
 * white on gold when selected and gold on transparent otherwise.
 *
 * An item whose `pricelistParentId` points at another item is shown inside
 * that item's row rather than on its own — the live page does this for
 * Four Hand Warm Candle under Organic Warm Candle Oil Massage.
 */
export type PriceTab = { label: string; itemIds: string[] };

/**
 * The home-service page puts two composite rows in its tabs instead of plain
 * price-list ids (see the header of src/data/pages/home-service.ts):
 *   "group:couple-massage" — one row holding every couple option
 *   "packages:couples"     — the couple packages, one row each
 * Pass `coupleGroup` and `couplePackagesGroupId` when a tab uses them.
 */
export type CoupleGroup = {
  name: string;
  description?: string;
  image: { src: string; alt: string; width: number; height: number };
  itemIds: string[];
};

export default function PriceListTabs({
  tabs,
  coupleGroup,
  couplePackagesGroupId,
}: {
  tabs: PriceTab[];
  coupleGroup?: CoupleGroup;
  couplePackagesGroupId?: string;
}) {
  const [active, setActive] = useState(0);

  return (
    <div>
      <ul className="flex flex-wrap justify-center gap-3">
        {tabs.map((item, i) => (
          <li key={item.label}>
            <button
              type="button"
              aria-pressed={i === active}
              onClick={() => setActive(i)}
              className={`rounded-full border border-gold px-6 py-[15px] text-[17px] leading-none font-semibold transition-colors ${
                i === active
                  ? "bg-gold text-white"
                  : "bg-transparent text-gold hover:bg-gold/10"
              }`}
            >
              {item.label}
            </button>
          </li>
        ))}
      </ul>

      {/* Every tab's list stays in the HTML and inactive ones are hidden, so
          search engines still see all the prices — the live page does the
          same. Rendering only the open tab would drop most of the page. */}
      {tabs.map((tab, tabIndex) => {
        const plainIds = tab.itemIds.filter((id) => !id.includes(":"));
        const rows = plainIds
          .map((id) => getPriceItem(id))
          .filter((item) => !item.pricelistParentId);
        const childrenOf = (parentId: string) =>
          plainIds
            .map((id) => getPriceItem(id))
            .filter((item) => item.pricelistParentId === parentId);

        const showCoupleGroup =
          coupleGroup != null && tab.itemIds.includes("group:couple-massage");
        const couplePackages =
          couplePackagesGroupId != null && tab.itemIds.includes("packages:couples")
            ? getPackageGroup(couplePackagesGroupId)
            : null;

        return (
          <ul
            key={tab.label}
            hidden={tabIndex !== active}
            aria-label={tab.label}
            className="mt-12 grid gap-x-12 gap-y-10 lg:grid-cols-2"
          >
            {showCoupleGroup && (
              <li key="group:couple-massage" className="flex gap-5">
                <Image
                  src={coupleGroup.image.src}
                  alt=""
                  aria-hidden
                  width={96}
                  height={92}
                  className="h-[92px] w-[96px] shrink-0 rounded-sm object-cover"
                />
                <div className="min-w-0 grow">
                  <h3 className="font-display text-[25px] leading-[31px] font-medium text-ink">
                    {coupleGroup.name}
                  </h3>
                  {coupleGroup.description && (
                    <p className="mt-1 text-[16px] leading-[29px] text-body">
                      {coupleGroup.description}
                    </p>
                  )}
                  <dl className="mt-3 space-y-1">
                    {coupleGroup.itemIds.map((id) => {
                      const member = getPriceItem(id);
                      return member.options.map((option) => (
                        <div
                          key={`${id}-${option.label}`}
                          className="flex justify-between gap-4 text-[16px] leading-[28px]"
                        >
                          <dt className="text-body">
                            {member.pricelistName ?? member.id} · {option.label}
                          </dt>
                          <dd className="font-semibold text-ink">{formatPrice(option.price)}</dd>
                        </div>
                      ));
                    })}
                  </dl>
                </div>
              </li>
            )}

            {couplePackages?.packages.map((item) => (
              <li key={`pkg-${item.name}`} className="flex gap-5">
                <div className="min-w-0 grow">
                  <h3 className="font-display text-[25px] leading-[31px] font-medium text-ink">
                    {couplePackages.title} {item.name}
                  </h3>
                  <dl className="mt-3 space-y-1">
                    <div className="flex justify-between gap-4 text-[16px] leading-[28px]">
                      <dt className="text-body">
                        {item.items.map((line) => line.treatment).join(" · ")}
                      </dt>
                      <dd className="font-semibold text-ink">{formatPrice(item.price)}</dd>
                    </div>
                  </dl>
                </div>
              </li>
            ))}

            {rows.map((item) => {
              const name = item.pricelistName ?? item.id;
              const extras = childrenOf(item.id);
              return (
                <li key={item.id} className="flex gap-5">
                  <Image
                    src={item.image.src}
                    alt=""
                    aria-hidden
                    width={96}
                    height={92}
                    className="h-[92px] w-[96px] shrink-0 rounded-sm object-cover"
                  />

                  <div className="min-w-0 grow">
                    <h3 className="font-display text-[25px] leading-[31px] font-medium text-ink">
                      {item.pageSlug ? (
                        <Link
                          href={`/seminyak/${item.pageSlug}/`}
                          className="transition-colors hover:text-gold"
                        >
                          {name}
                        </Link>
                      ) : (
                        name
                      )}
                    </h3>

                    {item.pricelistDescription && (
                      <p className="mt-1 text-[16px] leading-[29px] text-body">
                        {item.pricelistDescription}
                      </p>
                    )}

                    <dl className="mt-3 space-y-1">
                      {item.options.map((option) => (
                        <div
                          key={option.label}
                          className="flex justify-between gap-4 text-[16px] leading-[28px]"
                        >
                          <dt className="text-body">{option.label}</dt>
                          <dd className="font-semibold text-ink">
                            {formatPrice(option.price)}
                          </dd>
                        </div>
                      ))}
                    </dl>

                    {extras.map((extra) => (
                      <div
                        key={extra.id}
                        className="mt-4 border-t border-black/10 pt-3"
                      >
                        <h4 className="text-[16px] leading-[28px] font-semibold text-ink">
                          {extra.pricelistName ?? extra.id}
                        </h4>
                        <dl className="mt-1 space-y-1">
                          {extra.options.map((option) => (
                            <div
                              key={option.label}
                              className="flex justify-between gap-4 text-[16px] leading-[28px]"
                            >
                              <dt className="text-body">{option.label}</dt>
                              <dd className="font-semibold text-ink">
                                {formatPrice(option.price)}
                              </dd>
                            </div>
                          ))}
                        </dl>
                      </div>
                    ))}

                    <a
                      href={whatsappLink({ treatment: name })}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="mt-3 inline-block text-[16px] leading-[28px] font-semibold text-gold hover:underline"
                    >
                      Book {name}
                    </a>
                  </div>
                </li>
              );
            })}
          </ul>
        );
      })}
    </div>
  );
}
