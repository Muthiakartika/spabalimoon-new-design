import ContentBlocks from "@/components/ui/ContentBlocks";
import PageTitleBanner from "@/components/ui/PageTitleBanner";
import type { TextPage } from "@/data/types";

/**
 * Shared layout for the long-form pages: the wellness guide, the privacy
 * policy and the terms. Banner, then a single 674px column of content.
 *
 * Measured on the live site: banner 526px, body section padding roughly
 * 100px top and bottom.
 */
export default function TextPageLayout({ page }: { page: TextPage }) {
  return (
    <>
      <PageTitleBanner title={page.title} />
      <section className="pt-[100px] pb-[100px]">
        <div className="container-site">
          <ContentBlocks blocks={page.blocks} />
        </div>
      </section>
    </>
  );
}
