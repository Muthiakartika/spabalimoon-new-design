import RelatedTreatments from "@/components/treatments/RelatedTreatments";
import Sections from "@/components/treatments/Sections";
import TreatmentHero from "@/components/treatments/TreatmentHero";
import CtaPanel from "@/components/ui/CtaPanel";
import FaqAccordion from "@/components/ui/FaqAccordion";
import type { CallToAction, FaqBlock, PageSection, SiteImage } from "@/data/types";

/**
 * Shared layout for the pages built the same way as a treatment page:
 * /massage-kuta/ and /villa-hotel-massage/.
 *
 * Same order as the live pages — banner, body sections, FAQ, related
 * treatments, closing CTA.
 */
export default function SectionsPageLayout({
  hero,
  sections,
  faq,
  related,
  cta,
  bookingName,
  faqName,
}: {
  hero: { eyebrow?: string; title: string; image: SiteImage };
  sections: PageSection[];
  faq?: FaqBlock;
  related?: { eyebrow?: string; heading: string };
  cta?: CallToAction;
  bookingName: string;
  faqName: string;
}) {
  return (
    <>
      <TreatmentHero
        eyebrow={hero.eyebrow}
        title={hero.title}
        image={hero.image}
        bookingName={bookingName}
      />

      <Sections sections={sections} name={bookingName} />

      {faq && <FaqAccordion faq={faq} name={faqName} />}

      {related && (
        <RelatedTreatments eyebrow={related.eyebrow} heading={related.heading} excludeSlug="" />
      )}

      {cta && <CtaPanel cta={cta} />}
    </>
  );
}
