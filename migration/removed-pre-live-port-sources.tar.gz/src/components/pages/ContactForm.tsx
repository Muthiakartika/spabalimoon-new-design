"use client";

import { useState } from "react";
import { contactPage } from "@/data/pages/contact";
import { whatsappNumberLink } from "@/lib/whatsapp";

/**
 * Contact form.
 *
 * ⚠️ The old form posted to the site's own backend behind Cloudflare Turnstile
 * (see migration/migration-audit.md, FUNC-01). That backend is not part of this
 * rebuild, so rather than pretend to send an email the form composes the same
 * message and hands it to WhatsApp — the channel the rest of the site books
 * through. Swap `onSubmit` for a real endpoint when one exists.
 */
export default function ContactForm() {
  const { fields, submitLabel, resetLabel } = contactPage.form;
  const [values, setValues] = useState<Record<string, string>>({});

  function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const lines = fields
      .map((field) => {
        const label = field.label.replace(/\s*\*$/, "");
        const value = values[field.label]?.trim();
        return value ? `${label}: ${value}` : null;
      })
      .filter(Boolean);
    window.open(whatsappNumberLink(lines.join("\n")), "_blank", "noopener,noreferrer");
  }

  return (
    <form onSubmit={onSubmit} onReset={() => setValues({})} className="grid gap-5 sm:grid-cols-2">
      {fields.map((field, i) => {
        const isMessage = /message/i.test(field.label);
        const id = `contact-${i}`;
        return (
          <div key={field.label} className={isMessage ? "sm:col-span-2" : ""}>
            <label htmlFor={id} className="block text-[16px] leading-[28px] text-body">
              {field.label}
            </label>
            {isMessage ? (
              <textarea
                id={id}
                rows={5}
                required={field.label.includes("*")}
                placeholder={field.placeholder}
                value={values[field.label] ?? ""}
                onChange={(e) => setValues((v) => ({ ...v, [field.label]: e.target.value }))}
                className="mt-1 w-full rounded-sm border border-black/10 px-4 py-3 text-[16px] outline-none focus:border-gold"
              />
            ) : (
              <input
                id={id}
                type={/email/i.test(field.label) ? "email" : "text"}
                required={field.label.includes("*")}
                placeholder={field.placeholder}
                value={values[field.label] ?? ""}
                onChange={(e) => setValues((v) => ({ ...v, [field.label]: e.target.value }))}
                className="mt-1 w-full rounded-sm border border-black/10 px-4 py-3 text-[16px] outline-none focus:border-gold"
              />
            )}
          </div>
        );
      })}

      <div className="flex gap-4 sm:col-span-2">
        <button
          type="submit"
          className="rounded-[30px] bg-gold px-[30px] py-[16px] text-[16px] leading-none font-semibold text-white transition-opacity hover:opacity-90"
        >
          {submitLabel}
        </button>
        <button
          type="reset"
          className="rounded-[30px] border-2 border-gold px-[30px] py-[16px] text-[16px] leading-none font-semibold text-gold transition-colors hover:bg-gold hover:text-white"
        >
          {resetLabel}
        </button>
      </div>

      <p className="text-[14px] leading-[24px] text-body sm:col-span-2">
        Sending opens WhatsApp with your message ready to send.
      </p>
    </form>
  );
}
