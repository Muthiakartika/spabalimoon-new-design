import Image from "next/image";
import Button from "@/components/ui/Button";
import Testimonials from "@/components/treatments/Testimonials";
import type {
  IntroSection,
  ListSection,
  PackagesSection,
  PageSection,
  PricingSection,
  StatsSection,
} from "@/data/types";
import { getPackageGroup } from "@/data/packages";
import { formatPrice } from "@/lib/format";
import { whatsappLink } from "@/lib/whatsapp";

/**
 * The body sections of a treatment page. One renderer per section `type` in
 * src/data/types.ts, so a treatment file decides its own page order.
 *
 * Measured on the live site (viewport 1024px):
 *   eyebrow      <p>  20px / 400, #707070
 *   heading      <h2> 55px / 300 / line-height 65px, #1c1a1d
 *   price card   255×224 — price <p> 38px/300, label <h3> 16px/500,
 *                points <ul> 16px/400 #707070
 *   package price 55px / 300
 *   stat title   <h3> 30px / 500 / line-height 45px
 *   list item    16px / 500, #707070
 *
 * Sections alternate white and #f5f2ec down the page; the caller passes `tone`.
 */
type Tone = "white" | "sand";

const pad = "pt-[163px] pb-[157px]";
const padAlt = "pt-[143px] pb-[137px]";

function Shell({
  tone,
  alt,
  children,
}: {
  tone: Tone;
  alt?: boolean;
  children: React.ReactNode;
}) {
  return (
    <section className={`${tone === "sand" ? "bg-sand" : ""} ${alt ? padAlt : pad}`}>
      <div className="container-site">{children}</div>
    </section>
  );
}

function Heading({ eyebrow, heading }: { eyebrow?: string; heading: string }) {
  return (
    <>
      {eyebrow && <p className="text-[20px] leading-[30px] text-body">{eyebrow}</p>}
      <h2 className="mt-2 font-display text-[55px] leading-[65px] font-light capitalize text-ink">
        {heading}
      </h2>
    </>
  );
}

function Paragraphs({ items }: { items?: string[] }) {
  if (!items?.length) return null;
  return (
    <>
      {items.map((text) => (
        <p key={text} className="mt-4 text-[16px] leading-[29px] text-body">
          {text}
        </p>
      ))}
    </>
  );
}

function Intro({ section, tone }: { section: IntroSection; tone: Tone }) {
  return (
    <Shell tone={tone} alt>
      <div className="grid gap-12 lg:grid-cols-2">
        <div>
          <Heading eyebrow={section.eyebrow} heading={section.heading} />
          <Paragraphs items={section.paragraphs} />

          {section.highlights && (
            <dl className="mt-8 grid gap-6 sm:grid-cols-2">
              {section.highlights.map((item) => (
                <div key={item.title}>
                  <dt className="font-display text-[24px] leading-[35px] font-medium text-ink">
                    {item.title}
                  </dt>
                  <dd className="mt-1 text-[16px] leading-[29px] text-body">{item.text}</dd>
                </div>
              ))}
            </dl>
          )}
        </div>

        {section.images?.[0] && (
          <div className="grid gap-4 sm:grid-cols-2">
            {section.images.slice(0, 4).map((img) => (
              <Image
                key={img.src}
                src={img.src}
                alt={img.alt}
                width={img.width}
                height={img.height}
                className="h-full w-full rounded-sm object-cover"
              />
            ))}
          </div>
        )}
      </div>
    </Shell>
  );
}

function Pricing({ section, tone, name }: { section: PricingSection; tone: Tone; name: string }) {
  return (
    <Shell tone={tone}>
      <div className="text-center">
        <Heading eyebrow={section.eyebrow} heading={section.heading} />
      </div>
      <div className="mx-auto max-w-[820px] text-center">
        <Paragraphs items={section.paragraphs} />
      </div>

      {section.groups.map((group, gi) => (
        <div key={group.title ?? gi} className="mt-14">
          {group.title && (
            <h3 className="mb-8 text-center font-display text-[30px] leading-[45px] font-medium text-ink">
              {group.title}
            </h3>
          )}
          <ul className="grid justify-center gap-10 sm:grid-cols-2 xl:grid-cols-3">
            {group.cards.map((card) => (
              <li key={`${card.label}-${card.price}`} className="w-[255px] max-w-full">
                <p className="font-display text-[38px] leading-[48px] font-light text-ink">
                  {formatPrice(card.price)}
                </p>
                <h3 className="text-[16px] leading-[28px] font-medium text-ink">{card.label}</h3>
                {card.points && (
                  <ul className="mt-2 space-y-1 text-[16px] leading-[28px] text-body">
                    {card.points.map((point) => (
                      <li key={point}>{point}</li>
                    ))}
                  </ul>
                )}
                {card.bookButton && (
                  <Button
                    href={whatsappLink({ treatment: `${name} — ${card.label}` })}
                    external
                    className="mt-4"
                  >
                    Book Now
                  </Button>
                )}
              </li>
            ))}
          </ul>
        </div>
      ))}
    </Shell>
  );
}

function Packages({ section, tone }: { section: PackagesSection; tone: Tone }) {
  const group = getPackageGroup(section.packageGroup);

  return (
    <Shell tone={tone}>
      <div className="text-center">
        <Heading eyebrow={section.eyebrow} heading={section.heading} />
      </div>
      <div className="mx-auto max-w-[820px] text-center">
        <Paragraphs items={section.paragraphs} />
      </div>

      <ul className="mt-14 grid justify-center gap-8 sm:grid-cols-2 xl:grid-cols-4">
        {group.packages.map((item) => {
          const price = section.priceOverrides?.[item.name] ?? item.price;
          return (
            <li
              key={item.name}
              className="flex min-h-[508px] w-[320px] max-w-full flex-col rounded-sm bg-white px-8 py-12 text-center"
            >
              <h3 className="font-display text-[24px] leading-[35px] font-medium text-ink">
                {group.title} {item.name}
              </h3>
              <p className="mt-4 font-display text-[55px] leading-[65px] font-light text-ink">
                {formatPrice(price)}
              </p>
              {item.pax && (
                <span className="text-[16px] leading-[28px] text-body">for {item.pax} guests</span>
              )}
              <ul className="mt-6 grow space-y-2 text-[16px] leading-[29px] text-body">
                {item.items.map((line) => (
                  <li key={line.treatment}>
                    <span className="text-gold">{line.duration}</span> {line.treatment}
                  </li>
                ))}
              </ul>
              <Button
                href={whatsappLink({ packageName: `${group.title} ${item.name}` })}
                external
                className="mt-8"
              >
                Reserve
              </Button>
            </li>
          );
        })}
      </ul>
    </Shell>
  );
}

function Stats({ section, tone }: { section: StatsSection; tone: Tone }) {
  return (
    <Shell tone={tone} alt>
      <ul className="grid gap-10 sm:grid-cols-2 xl:grid-cols-4">
        {section.items.map((item) => (
          <li key={item.title} className="text-center">
            <h3 className="font-display text-[30px] leading-[45px] font-medium text-ink">
              {item.title}
            </h3>
            <p className="mt-2 text-[16px] leading-[29px] text-body">{item.text}</p>
          </li>
        ))}
      </ul>
    </Shell>
  );
}

function ListBlock({ section, tone, name }: { section: ListSection; tone: Tone; name: string }) {
  return (
    <Shell tone={tone} alt={tone === "white"}>
      <div className="grid items-center gap-12 lg:grid-cols-2">
        {section.image && (
          <div className="relative order-2 lg:order-1">
            <Image
              src={section.image.src}
              alt={section.image.alt}
              width={section.image.width}
              height={section.image.height}
              className="w-full max-w-[376px] h-auto rounded-sm object-cover"
            />
            {section.imageBadge && (
              <span className="absolute top-6 left-6 rounded-sm bg-gold px-4 py-2 text-center text-[14px] leading-[20px] font-semibold text-white">
                {section.imageBadge.map((line) => (
                  <span key={line} className="block">
                    {line}
                  </span>
                ))}
              </span>
            )}
            {section.imageCaption && (
              <span className="absolute right-6 bottom-6 font-display text-[24px] leading-[30px] text-white">
                {section.imageCaption.map((line) => (
                  <span key={line} className="block">
                    {line}
                  </span>
                ))}
              </span>
            )}
          </div>
        )}

        <div className={section.image ? "order-1 lg:order-2" : "lg:col-span-2"}>
          <Heading eyebrow={section.eyebrow} heading={section.heading} />
          <Paragraphs items={section.paragraphs} />

          <ul className="mt-6 space-y-2">
            {section.items.map((item) => (
              <li
                key={item}
                className="flex items-start gap-2 text-[16px] leading-[28px] font-medium text-body"
              >
                <Image
                  src="/icons/kicker-flourish.svg"
                  alt=""
                  aria-hidden
                  width={18}
                  height={19}
                  className="mt-1 shrink-0"
                />
                <span>{item}</span>
              </li>
            ))}
          </ul>

          {section.button && (
            <Button
              href={section.button.href ?? whatsappLink({ treatment: name })}
              external={!section.button.href}
              className="mt-8"
            >
              {section.button.label}
            </Button>
          )}
        </div>
      </div>
    </Shell>
  );
}

export default function Sections({ sections, name }: { sections: PageSection[]; name: string }) {
  let toneIndex = 0;
  const nextTone = (): Tone => (toneIndex++ % 2 === 0 ? "white" : "sand");

  return (
    <>
      {sections.map((section, i) => {
        const tone = nextTone();
        switch (section.type) {
          case "intro":
            return <Intro key={i} section={section} tone={tone} />;
          case "pricing":
            return <Pricing key={i} section={section} tone={tone} name={name} />;
          case "packages":
            return <Packages key={i} section={section} tone={tone} />;
          case "stats":
            return <Stats key={i} section={section} tone={tone} />;
          case "list":
            return <ListBlock key={i} section={section} tone={tone} name={name} />;
          case "testimonials":
            return <Testimonials key={i} />;
          default:
            return null;
        }
      })}
    </>
  );
}
