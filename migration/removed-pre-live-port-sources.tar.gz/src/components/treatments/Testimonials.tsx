import Image from "next/image";
import Carousel from "@/components/ui/Carousel";
import { testimonials } from "@/data/testimonials";

/**
 * Guest reviews. One review fills the width at a time and the slide advances
 * on a timer, as on the live site.
 *
 * Measured on the live site (viewport 1024px):
 *   section    padding 100px top / 131px bottom, height 515px
 *   slide      936×226, centred
 *   quote      <p>  16px / 400 / line-height 28px, #1c1a1d
 *   name       <h4> 22px / 500 / line-height 32px, #1c1a1d
 *   role       <span> 16px / 400, #707070 — the words "Customer review"
 *   watermark  /images/logo/sbm.webp at 378×295, centred behind the text
 *
 * The live site shows five stars on every review. They are decorative here:
 * no rating is stored with the reviews (see migration-audit.md SEO-03).
 */
function Stars() {
  return (
    <div className="flex justify-center gap-1" aria-hidden>
      {Array.from({ length: 5 }, (_, i) => (
        <svg key={i} width="16" height="16" viewBox="0 0 24 24" fill="var(--color-review)">
          <path d="M12 2l2.9 6.6 7.1.6-5.4 4.7 1.6 7L12 17.3 5.8 20.9l1.6-7L2 9.2l7.1-.6L12 2z" />
        </svg>
      ))}
    </div>
  );
}

export default function Testimonials() {
  return (
    <section className="relative overflow-hidden pt-[100px] pb-[131px]">
      {/* Leaf against the left edge */}
      <Image
        src="/images/shape/testimonial-two-shape-left.png"
        alt=""
        aria-hidden
        width={270}
        height={400}
        className="pointer-events-none absolute top-0 left-0 hidden w-[270px] h-auto select-none xl:block"
      />
      <Image
        src="/images/shape/testimonial-two-shape-right.png"
        alt=""
        aria-hidden
        width={270}
        height={400}
        className="pointer-events-none absolute right-0 bottom-0 hidden w-[270px] h-auto select-none xl:block"
      />

      <div className="container-site relative">
        {/* Lotus watermark sitting behind the quote */}
        <Image
          src="/images/logo/sbm.webp"
          alt=""
          aria-hidden
          width={420}
          height={328}
          className="pointer-events-none absolute top-1/2 left-1/2 w-[420px] h-auto -translate-x-1/2 -translate-y-1/2 select-none opacity-15"
        />

        <Carousel label="Guest reviews" autoplayMs={5000} slideClassName="w-full">
          {testimonials.map((review) => (
            // The live slide measures 936x226; the spacing below is what makes
            // up that height around the three lines of text.
            <figure
              key={review.name + review.text}
              className="mx-auto flex min-h-[226px] max-w-[936px] flex-col items-center justify-center text-center"
            >
              <Stars />
              <blockquote className="mt-8">
                <p className="text-[16px] leading-[28px] text-ink">{review.text}</p>
              </blockquote>
              <figcaption className="mt-8">
                <h4 className="font-display text-[22px] leading-[32px] font-medium text-ink">
                  {review.name}
                </h4>
                <span className="text-[16px] leading-[28px] text-body">Customer review</span>
              </figcaption>
            </figure>
          ))}
        </Carousel>
      </div>
    </section>
  );
}
