import Image from "next/image";
import type { SiteImage } from "@/data/types";
import { whatsappLink } from "@/lib/whatsapp";

/**
 * Banner at the top of every treatment page.
 *
 * Measured on the live site (viewport 1024px):
 *   panel    1016×848, the photo applied as a background-image
 *   eyebrow  20px / 300, white
 *   h1       110px / 300 / line-height 130px, white
 *   button   "Book Now", opens WhatsApp
 *
 * A dark scrim keeps the white text readable over any photo.
 */
export default function TreatmentHero({
  eyebrow,
  title,
  image,
  bookingName,
}: {
  eyebrow?: string;
  title: string;
  image: SiteImage;
  bookingName: string;
}) {
  return (
    <section className="relative flex min-h-[848px] items-center overflow-hidden">
      <Image
        src={image.src}
        alt={image.alt}
        fill
        priority
        sizes="100vw"
        className="object-cover"
      />
      <div aria-hidden className="absolute inset-0 bg-ink/45" />

      {/* Leaf that overlaps the lower-right corner on the live site */}
      <Image
        src="/images/shape/banner-two-shape.png"
        alt=""
        aria-hidden
        width={325}
        height={331}
        className="pointer-events-none absolute right-0 bottom-0 hidden w-[325px] h-auto select-none lg:block"
      />

      <div className="container-site relative py-24">
        {eyebrow && (
          <p className="font-display text-[20px] leading-[29px] font-light text-white">{eyebrow}</p>
        )}
        <h1 className="mt-2 max-w-[936px] font-display text-[clamp(44px,8vw,110px)] leading-[1.18] font-light text-white">
          {title}
        </h1>
        <a
          href={whatsappLink({ treatment: bookingName })}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-8 inline-block rounded-[30px] bg-white px-[30px] py-[16px] text-[16px] leading-none font-semibold text-gold transition-opacity hover:opacity-90"
        >
          Book Now
        </a>
      </div>
    </section>
  );
}
