import Image from "next/image";
import Link from "next/link";
import Carousel from "@/components/ui/Carousel";
import { getTreatment, relatedTreatmentSlugs } from "@/data/treatments";

/**
 * "Explore Beyond Your <treatment>" — the slider of other treatments at the
 * foot of each treatment page.
 *
 * Measured on the live site: section 832px tall, padding 143px / 102px.
 * Cards use each treatment's own card photo and short description.
 */
export default function RelatedTreatments({
  eyebrow,
  heading,
  excludeSlug,
}: {
  eyebrow?: string;
  heading: string;
  excludeSlug: string;
}) {
  const items = relatedTreatmentSlugs
    .filter((slug) => slug !== excludeSlug)
    .map((slug) => getTreatment(slug))
    .filter((t) => t != null);

  if (!items.length) return null;

  return (
    <section className="pt-[143px] pb-[102px]">
      <div className="container-site">
        <div className="text-center">
          {eyebrow && <p className="text-[20px] leading-[30px] text-body">{eyebrow}</p>}
          <h2 className="mt-2 font-display text-[55px] leading-[65px] font-light capitalize text-ink">
            {heading}
          </h2>
        </div>

        <Carousel label="Other treatments" autoplayMs={4000} slideClassName="w-[300px]" className="mt-12">
          {items.map((item) => (
            <Link
              key={item.slug}
              href={`/seminyak/${item.slug}/`}
              className="group block text-center"
            >
              <Image
                src={item.cardImage.src}
                alt={item.cardImage.alt}
                width={item.cardImage.width}
                height={item.cardImage.height}
                className="h-[280px] w-full rounded-sm object-cover transition-transform duration-500 group-hover:scale-[1.03]"
              />
              <h3 className="mt-4 font-display text-[24px] leading-[35px] font-medium text-ink transition-colors group-hover:text-gold">
                {item.cardName ?? item.name}
              </h3>
              {item.shortDescription && (
                <p className="mt-1 text-[16px] leading-[29px] text-body">{item.shortDescription}</p>
              )}
            </Link>
          ))}
        </Carousel>
      </div>
    </section>
  );
}
