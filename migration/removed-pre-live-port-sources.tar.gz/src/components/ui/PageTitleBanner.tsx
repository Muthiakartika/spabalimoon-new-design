import Image from "next/image";

/**
 * The banner at the top of the long-form text pages.
 *
 * Measured on the live site (viewport 1024px):
 *   section  526px tall, photo as the background
 *   h1       64px / 700 / line-height 130px, white
 */
export default function PageTitleBanner({
  title,
  image = "/images/bg/page-title-bg.jpg",
}: {
  title: string;
  image?: string;
}) {
  return (
    <section className="relative flex min-h-[526px] items-center overflow-hidden">
      <Image src={image} alt="" aria-hidden fill priority sizes="100vw" className="object-cover" />
      <div aria-hidden className="absolute inset-0 bg-ink/50" />
      <div className="container-site relative">
        <h1 className="font-display text-[clamp(36px,6vw,64px)] leading-[1.25] font-bold text-white">
          {title}
        </h1>
      </div>
    </section>
  );
}
