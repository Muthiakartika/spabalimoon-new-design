"use client";

import { useCallback, useEffect, useRef, useState } from "react";

/**
 * Lightweight replacement for the Swiper sliders on the live site.
 *
 * Swiper costs roughly 140 KB for what these sections actually use: a
 * horizontal track that advances on a timer and can be dragged. Native
 * scroll-snap does the dragging, so all that is left is the timer.
 *
 * Autoplay stops on hover, on keyboard focus, while the tab is hidden, and for
 * anyone who asked for reduced motion.
 */
export default function Carousel({
  children,
  autoplayMs = 3000,
  className = "",
  slideClassName = "",
  label,
  arrows = false,
}: {
  children: React.ReactNode[];
  autoplayMs?: number;
  className?: string;
  slideClassName?: string;
  label: string;
  /** Prev/next buttons under the track, as on the treatment slider. */
  arrows?: boolean;
}) {
  const trackRef = useRef<HTMLUListElement>(null);
  const [paused, setPaused] = useState(false);

  const step = useCallback((dir: 1 | -1) => {
    const track = trackRef.current;
    if (!track) return;
    const first = track.firstElementChild as HTMLElement | null;
    if (!first) return;
    const width =
      first.getBoundingClientRect().width +
      parseFloat(getComputedStyle(track).columnGap || "0");
    if (dir === 1) {
      const atEnd = track.scrollLeft + track.clientWidth >= track.scrollWidth - 2;
      track.scrollTo({ left: atEnd ? 0 : track.scrollLeft + width, behavior: "smooth" });
    } else {
      const atStart = track.scrollLeft <= 2;
      track.scrollTo({
        left: atStart ? track.scrollWidth : track.scrollLeft - width,
        behavior: "smooth",
      });
    }
  }, []);

  const advance = useCallback(() => step(1), [step]);

  useEffect(() => {
    if (paused || autoplayMs <= 0) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

    const id = window.setInterval(() => {
      if (document.hidden) return;
      advance();
    }, autoplayMs);
    return () => window.clearInterval(id);
  }, [paused, autoplayMs, advance]);

  return (
    <div
      className={className}
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onFocusCapture={() => setPaused(true)}
      onBlurCapture={() => setPaused(false)}
    >
      <ul
        ref={trackRef}
        aria-label={label}
        className="flex snap-x snap-mandatory gap-6 overflow-x-auto scroll-smooth [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
      >
        {children.map((child, i) => (
          <li key={i} className={`shrink-0 snap-start ${slideClassName}`}>
            {child}
          </li>
        ))}
      </ul>

      {/* Centred prev/next pair, 60px below the track — 30×30 on #f9f6f1,
          matching the live treatment slider. */}
      {arrows && (
        <div className="mt-[60px] flex justify-center">
          {(
            [
              ["Previous slide", -1, "M9 2L3.5 7.5L9 13"],
              ["Next slide", 1, "M5 2l5.5 5.5L5 13"],
            ] as const
          ).map(([aria, dir, d]) => (
            <button
              key={aria}
              type="button"
              aria-label={aria}
              onClick={() => step(dir)}
              className="flex h-[30px] w-[30px] items-center justify-center bg-[#f9f6f1] text-[15px] text-ink transition-colors hover:text-gold"
            >
              <svg width="14" height="15" viewBox="0 0 14 15" fill="none" aria-hidden>
                <path d={d} stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
              </svg>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
