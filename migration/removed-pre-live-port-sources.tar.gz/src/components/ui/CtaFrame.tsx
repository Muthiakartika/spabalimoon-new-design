/**
 * The four hand-drawn rules that frame the closing CTA banner.
 *
 * Inlined rather than loaded as files: routing them through next/image left
 * them at naturalWidth 0 (the optimiser's `default-src 'self'` policy rejects
 * the inline `style` attributes inside the paths), and they are a few hundred
 * bytes each, so a network request buys nothing.
 *
 * Paths copied from the live site's SVGs. `preserveAspectRatio="none"` lets
 * each rule stretch to its box, and `vectorEffect="non-scaling-stroke"` keeps
 * the line the same weight however far it is stretched.
 *
 * Measured on the live banner (1408×442): the horizontal rules are 1356×30
 * inset 14px from the top and bottom, the vertical ones 30×390 inset 14px
 * from the left and right.
 */
const stroke = {
  fill: "none",
  strokeWidth: 2,
  strokeLinecap: "round" as const,
  vectorEffect: "non-scaling-stroke" as const,
};

const thin = { ...stroke, strokeWidth: 1.5 };

export default function CtaFrame() {
  return (
    <>
      <svg
        viewBox="0 0 1000 40"
        preserveAspectRatio="none"
        aria-hidden
        className="pointer-events-none absolute top-[14px] left-1/2 hidden h-[30px] w-[calc(100%-52px)] -translate-x-1/2 lg:block"
      >
        <path
          d="M0,22 C160,8 320,30 480,18 C640,8 820,30 1000,16"
          style={{ ...stroke, stroke: "rgba(255,255,255,0.6)" }}
        />
        <path
          d="M130,30 C300,22 450,32 620,26"
          style={{ ...thin, stroke: "rgba(255,255,255,0.3)" }}
        />
      </svg>

      <svg
        viewBox="0 0 1000 40"
        preserveAspectRatio="none"
        aria-hidden
        className="pointer-events-none absolute bottom-[14px] left-1/2 hidden h-[30px] w-[calc(100%-52px)] -translate-x-1/2 lg:block"
      >
        <path
          d="M0,18 C160,32 320,10 480,22 C640,32 820,10 1000,24"
          style={{ ...stroke, stroke: "rgba(255,255,255,0.6)" }}
        />
        <path
          d="M380,10 C560,18 720,8 880,14"
          style={{ ...thin, stroke: "rgba(255,255,255,0.3)" }}
        />
      </svg>

      <svg
        viewBox="0 0 40 1000"
        preserveAspectRatio="none"
        aria-hidden
        className="pointer-events-none absolute top-1/2 left-[14px] hidden h-[calc(100%-52px)] w-[30px] -translate-y-1/2 lg:block"
      >
        <path
          d="M22,0 C12,160 30,320 20,500 C12,680 30,840 22,1000"
          style={{ ...stroke, stroke: "rgba(255,255,255,0.55)" }}
        />
      </svg>

      <svg
        viewBox="0 0 40 1000"
        preserveAspectRatio="none"
        aria-hidden
        className="pointer-events-none absolute top-1/2 right-[14px] hidden h-[calc(100%-52px)] w-[30px] -translate-y-1/2 lg:block"
      >
        <path
          d="M18,0 C28,160 10,320 20,500 C28,680 10,840 18,1000"
          style={{ ...stroke, stroke: "rgba(255,255,255,0.55)" }}
        />
      </svg>
    </>
  );
}
