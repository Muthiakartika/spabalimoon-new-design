import Link from "next/link";

/**
 * The outlined gold button used across the site ("Discover More", "Book Now").
 *
 * Measured on the live site:
 *   Mulish 16px / 600, gold text, transparent background,
 *   2px solid gold border, border-radius 30px, padding 16px 30px
 */
export default function Button({
  href,
  children,
  external = false,
  className = "",
}: {
  href: string;
  children: React.ReactNode;
  external?: boolean;
  className?: string;
}) {
  const classes = `inline-block rounded-[30px] border-2 border-gold px-[30px] py-[16px] text-[16px] leading-none font-semibold text-gold transition-colors hover:bg-gold hover:text-white ${className}`;

  if (external) {
    return (
      <a href={href} target="_blank" rel="noopener noreferrer" className={classes}>
        {children}
      </a>
    );
  }

  return (
    <Link href={href} className={classes}>
      {children}
    </Link>
  );
}
