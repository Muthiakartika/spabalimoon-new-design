import Link from "next/link";
import type { ContentBlock } from "@/data/types";
import { whatsappLink } from "@/lib/whatsapp";

/**
 * Renders the long-form body of a text page (wellness guide, privacy policy,
 * terms) from src/data/pages/<page>.ts.
 *
 * Measured on the live site (viewport 1024px):
 *   column     674px
 *   <h2>       28px / 500 / line-height 65px, #1c1a1d
 *   paragraph  16px / 400 / line-height 30.4px, #5f5a54
 *              (note: a warmer grey than the #707070 used elsewhere)
 *
 * A link whose href is "whatsapp" opens the booking chat, as the data promises.
 */
const headingSize: Record<number, string> = {
  2: "text-[28px] leading-[65px]",
  3: "text-[24px] leading-[45px]",
  4: "text-[22px] leading-[40px]",
  5: "text-[20px] leading-[36px]",
  6: "text-[18px] leading-[32px]",
};

function resolve(href: string) {
  return href === "whatsapp" ? whatsappLink() : href;
}

export default function ContentBlocks({ blocks }: { blocks: ContentBlock[] }) {
  return (
    <div className="mx-auto max-w-[674px] text-[16px] leading-[30.4px] text-[#5f5a54]">
      {blocks.map((block, i) => {
        switch (block.kind) {
          case "heading": {
            const Tag = `h${block.level}` as "h2" | "h3" | "h4" | "h5" | "h6";
            const classes = `mt-10 font-display font-medium text-ink ${headingSize[block.level]}`;
            return (
              <Tag key={i} className={classes}>
                {block.href ? (
                  <Link href={resolve(block.href)} className="transition-colors hover:text-gold">
                    {block.text}
                  </Link>
                ) : (
                  block.text
                )}
              </Tag>
            );
          }

          case "paragraph":
            return (
              <p key={i} className="mt-5">
                {block.lead && <strong className="font-semibold text-ink">{block.lead} </strong>}
                {block.text}
              </p>
            );

          case "list":
            return (
              <ul key={i} className="mt-5 list-disc space-y-2 pl-6">
                {block.items.map((item) => (
                  <li key={item.text}>
                    {item.lead && <strong className="font-semibold text-ink">{item.lead} </strong>}
                    {item.text}
                  </li>
                ))}
              </ul>
            );

          case "link":
            return (
              <p key={i} className="mt-5">
                <Link
                  href={resolve(block.href)}
                  className="font-semibold text-gold hover:underline"
                  {...(block.href === "whatsapp"
                    ? { target: "_blank", rel: "noopener noreferrer" }
                    : {})}
                >
                  {block.label}
                </Link>
              </p>
            );

          default:
            return null;
        }
      })}
    </div>
  );
}
