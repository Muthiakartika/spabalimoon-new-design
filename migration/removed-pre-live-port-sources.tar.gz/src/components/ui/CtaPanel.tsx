import Image from "next/image";
import type { CallToAction } from "@/data/types";
import CtaFrame from "@/components/ui/CtaFrame";
import { whatsappLink } from "@/lib/whatsapp";

/**
 * The dark closing panel used at the foot of the inner pages.
 *
 * Measured on the live site (viewport 1024px):
 *   section  padding 163px top / 157px bottom, height 733px
 *   heading  32px / 300, white
 *   copy     white, separated by 60×1 rules at rgba(255,255,255,0.5)
 *   button   gold text on white, fully rounded
 *
 * When the block carries a photo it becomes the panel background; otherwise
 * the panel is flat ink, as on the homepage.
 */
export default function CtaPanel({ cta, bookingName }: { cta: CallToAction; bookingName?: string }) {
  return (
    <section className="pt-[163px] pb-[157px]">
      <div className="container-site">
        <div className="relative mx-auto flex min-h-[442px] max-w-[936px] flex-col items-center justify-center overflow-hidden rounded-sm bg-ink px-6 py-16 text-center">
          <CtaFrame />
          {cta.image && (
            <>
              <Image
                src={cta.image.src}
                alt={cta.image.alt}
                fill
                sizes="(max-width: 936px) 100vw, 936px"
                className="object-cover"
              />
              <div aria-hidden className="absolute inset-0 bg-ink/60" />
            </>
          )}

          <div className="relative">
            <h2 className="mx-auto max-w-[796px] font-display text-[32px] leading-[41.6px] font-light text-white">
              {cta.heading}
            </h2>

            {cta.paragraphs.map((text, i) => (
              <div key={text}>
                <span aria-hidden className="mx-auto mt-6 block h-px w-[60px] bg-white/50" />
                <p
                  className={`mx-auto mt-6 text-[16px] leading-[29px] text-white ${
                    i === 0 ? "max-w-[720px]" : "max-w-[640px]"
                  }`}
                >
                  {text}
                </p>
              </div>
            ))}

            <a
              href={whatsappLink(bookingName ? { treatment: bookingName } : {})}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-8 inline-block rounded-[30px] bg-white px-[30px] py-[16px] text-[16px] leading-none font-semibold text-gold transition-opacity hover:opacity-90"
            >
              {cta.buttonLabel}
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
