import Image from "next/image";
import type { FaqBlock } from "@/data/types";

/**
 * FAQ block used on the treatment pages and anywhere else the same pattern
 * appears: a banner photo with a white heading over it, then a kicker, a
 * second heading and the questions.
 *
 * Measured on the live site (viewport 1024px):
 *   banner heading  white, 26.6px / 500
 *   kicker          20px / 400, #707070
 *   heading         55px / 300 / line-height 65px
 *   question        24px / 500 / line-height 35px, #1c1a1d
 *
 * Built from <details>/<summary> so it works without JavaScript and is
 * reachable by keyboard — the live site uses a scripted accordion.
 */
export default function FaqAccordion({ faq, name }: { faq: FaqBlock; name: string }) {
  return (
    <section className="bg-sand pt-[163px] pb-[157px]">
      <div className="container-site">
        {faq.image && (
          <div className="relative mx-auto max-w-[895px] overflow-hidden rounded-sm">
            <Image
              src={faq.image.src}
              alt={faq.image.alt}
              width={faq.image.width}
              height={faq.image.height}
              className="h-full w-full object-cover"
            />
            <h2 className="absolute inset-x-0 bottom-10 text-center font-display text-[26.624px] leading-[26.624px] font-medium text-white">
              {faq.heading}
            </h2>
          </div>
        )}

        <div className="mx-auto mt-16 max-w-[736px]">
          {faq.eyebrow && <p className="text-[20px] leading-[30px] text-body">{faq.eyebrow}</p>}
          {faq.subheading && (
            <h2 className="mt-2 font-display text-[55px] leading-[65px] font-light capitalize text-ink">
              {faq.subheading}
            </h2>
          )}

          <dl className="mt-10">
            {faq.items.map((item) => (
              <details
                key={item.question}
                className="group border-b border-black/10 py-5"
                name={`faq-${name}`}
              >
                <summary className="flex cursor-pointer items-start justify-between gap-4 font-display text-[24px] leading-[35px] font-medium text-ink marker:content-none [&::-webkit-details-marker]:hidden">
                  {item.question}
                  <span
                    aria-hidden
                    className="mt-3 shrink-0 text-gold transition-transform group-open:rotate-180"
                  >
                    <svg width="14" height="8" viewBox="0 0 14 8" fill="none">
                      <path d="M1 1l6 6 6-6" stroke="currentColor" strokeWidth="1.5" />
                    </svg>
                  </span>
                </summary>
                <p className="mt-3 text-[16px] leading-[29px] text-body">{item.answer}</p>
              </details>
            ))}
          </dl>
        </div>
      </div>
    </section>
  );
}
